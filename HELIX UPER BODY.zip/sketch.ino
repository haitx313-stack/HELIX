#include <Wire.h>
#include <Adafruit_SSD1306.h>
#include <FluxGarage_RoboEyes.h>
#include <Servo.h>

// OLED
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
RoboEyes<Adafruit_SSD1306> roboEyes(display);

// Pins
#define TRIG_PIN 9
#define ECHO_PIN 8
#define TOUCH_PIN 2
#define SERVO_PIN 6

Servo myServo;

// Variables
long duration;
int distance;

bool servoActive = false;
unsigned long servoTimer = 0;
unsigned long lastUltrasonic = 0;

void setup() {
  Serial.begin(9600);

  // I2C speed boost
  Wire.begin();
  Wire.setClock(400000);

  // OLED init
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("SSD1306 failed"));
    for(;;);
  }

  roboEyes.begin(SCREEN_WIDTH, SCREEN_HEIGHT, 100);
  roboEyes.setAutoblinker(ON, 3, 2);
  roboEyes.setIdleMode(ON, 2, 2);

  // Pins
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(TOUCH_PIN, INPUT);

  // Servo
  myServo.attach(SERVO_PIN);
  myServo.write(0);
}

void loop() {

  // ================== TOUCH SENSOR ==================
  if (digitalRead(TOUCH_PIN) == HIGH) {
    roboEyes.setMood(HAPPY);
    roboEyes.setVFlicker(ON, 4);
  } else {
    roboEyes.setMood(DEFAULT);
    roboEyes.setVFlicker(OFF, 0);
  }

  // ================== ULTRASONIC (NON-BLOCKING STYLE) ==================
  if (millis() - lastUltrasonic > 100) { // every 100ms

    digitalWrite(TRIG_PIN, LOW);
    delayMicroseconds(2);
    digitalWrite(TRIG_PIN, HIGH);
    delayMicroseconds(10);
    digitalWrite(TRIG_PIN, LOW);

    duration = pulseIn(ECHO_PIN, HIGH, 30000); // timeout added
    distance = duration * 0.034 / 2;

    lastUltrasonic = millis();
  }

  // ================== SERVO CONTROL ==================
  if (distance > 0 && distance < 20 && !servoActive) {
    myServo.write(90);
    servoActive = true;
    servoTimer = millis();
  }

  if (servoActive && millis() - servoTimer >= 2200) {
    myServo.write(0);
    servoActive = false;
  }

  // ================== OLED UPDATE ==================
  roboEyes.update();
}